import { useForm } from '@inertiajs/react';
import SlideOver from '@/Components/SlideOver';

function resolveTargetId(banner, promos) {
    if (!banner) return '';

    if (banner.promo_id) return String(banner.promo_id);
    const match = (promos || []).find((p) => p.title === banner.target_title);
    return match ? String(match.id) : '';
}

function BannerForm({ banner, promos, nextSortOrder, onClose }) {
    const editing = Boolean(banner);

    const form = useForm({
        target_id: resolveTargetId(banner, promos),
        promo_title: banner?.promo_title || '',
        sort_order: banner?.sort_order ?? nextSortOrder,
        is_active: banner ? Boolean(banner.is_active) : true,
        image: null,
        remove_image: false,
    });

    const existingImage = banner?.image_path && !form.data.remove_image ? `/storage/${banner.image_path}` : null;
    const newImagePreview = form.data.image ? URL.createObjectURL(form.data.image) : null;
    const imagePreview = newImagePreview || existingImage;

    form.transform((data) => ({
        type: 'promo',
        promo_title: data.promo_title || null,
        sort_order: Number(data.sort_order),
        is_active: Boolean(data.is_active),
        promo_id: data.target_id || null,
        agenda_id: null,
        image: data.image,
        remove_image: data.remove_image,
    }));

    const submit = (e) => {
        e.preventDefault();
        if (editing) {
            form.put(route('admin.banners.update', banner.id), { preserveScroll: true, forceFormData: true });
        } else {
            form.post(route('admin.banners.store'), { preserveScroll: true, forceFormData: true });
        }
    };

    const options = promos || [];
    const optionLabel = (item) => item.partner_name ? `${item.title} — ${item.partner_name}` : item.title;

    return (
        <form id="home-banner-form" onSubmit={submit} className="space-y-5">
            <div>
                <label className="label" htmlFor="banner-promo-title">Judul Promo (opsional override)</label>
                <input
                    id="banner-promo-title"
                    type="text"
                    className="input"
                    value={form.data.promo_title}
                    onChange={(e) => form.setData('promo_title', e.target.value)}
                    placeholder="Kosongkan jika menggunakan judul asli promo"
                />
                {form.errors.promo_title && <p className="mt-1 text-xs text-ember">{form.errors.promo_title}</p>}
            </div>
            <div>
                <label className="label" htmlFor="banner-target">Target Promo</label>
                <select
                    id="banner-target"
                    className="input"
                    value={form.data.target_id}
                    onChange={(e) => form.setData('target_id', e.target.value)}
                >
                    <option value="">Pilih promo…</option>
                    {options.map((item) => (
                        <option key={item.id} value={item.id}>
                            {optionLabel(item)}
                        </option>
                    ))}
                </select>
                {options.length === 0 && (
                    <p className="mt-1.5 text-xs text-slate">
                        Tidak ada promo tersedia saat ini.
                    </p>
                )}
                {form.errors.promo_id && <p className="mt-1 text-xs text-ember">{form.errors.promo_id}</p>}
                {form.errors.agenda_id && <p className="mt-1 text-xs text-ember">{form.errors.agenda_id}</p>}
            </div>

            <div>
                <label className="label" htmlFor="banner-image">Gambar (opsional)</label>
                <input
                    id="banner-image"
                    type="file"
                    accept=".jpg,.jpeg,.png,.webp"
                    className="input file:mr-3 file:rounded-full file:border-0 file:bg-ink file:px-4 file:py-1.5 file:text-xs file:font-semibold file:text-paper"
                    onChange={(e) => form.setData((data) => ({ ...data, image: e.target.files[0] || null, remove_image: false }))}
                />
                <p className="mt-1.5 text-xs text-slate">Format JPG/PNG/WebP, maksimal 2 MB. Rasio ideal 4:5 (misal 1080×1350px). Tampil sebagai cover banner di beranda member.</p>

                {imagePreview && (
                    <div className="mt-3 flex items-start gap-3">
                        <img src={imagePreview} alt="Pratinjau Banner" className="h-32 w-full max-w-[256px] rounded-xl border border-ink/10 object-cover" style={{ aspectRatio: '4/5' }} />
                        <button
                            type="button"
                            onClick={() => form.setData((data) => ({ ...data, image: null, remove_image: true }))}
                            className="btn-ghost text-xs"
                        >
                            Hapus
                        </button>
                    </div>
                )}
                {(form.errors.image || form.errors.remove_image) && (
                    <p className="mt-1 text-xs text-ember">{form.errors.image || form.errors.remove_image}</p>
                )}
            </div>

            <div>
                <label className="label" htmlFor="banner-sort">Urutan Tampilan</label>
                <input
                    id="banner-sort"
                    type="number"
                    min="1"
                    max="3"
                    className="input"
                    value={form.data.sort_order}
                    onChange={(e) => form.setData('sort_order', e.target.value)}
                />
                <p className="mt-1.5 text-xs text-slate">Angka lebih kecil akan muncul lebih awal di beranda member.</p>
                {form.errors.sort_order && <p className="mt-1 text-xs text-ember">{form.errors.sort_order}</p>}
            </div>

            <label className="flex items-center gap-3">
                <input
                    type="checkbox"
                    checked={form.data.is_active}
                    onChange={(e) => form.setData('is_active', e.target.checked)}
                    className="h-4 w-4 accent-gold"
                />
                <span className="text-sm">Tampilkan di beranda member</span>
            </label>

            <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={onClose} className="btn-ghost">
                    Batal
                </button>
                <button type="submit" className="btn-gold" disabled={form.processing}>
                    {form.processing ? 'Menyimpan…' : editing ? 'Simpan' : 'Simpan Banner'}
                </button>
            </div>
        </form>
    );
}

export default function HomeBannerDrawer({ drawer, onClose, promos = [], nextSortOrder = 1 }) {
    if (!drawer?.mode) return null;

    const banner = drawer.banner || drawer.info || null;
    const isEdit = drawer.mode === 'edit';

    return (
        <SlideOver
            open
            onClose={onClose}
            title={isEdit ? 'Edit Banner' : 'Tambah Banner Beranda'}
            subtitle={
                isEdit ? banner?.target_title : 'Unggulkan promo di beranda utama member.'
            }
            width="max-w-2xl"
        >
            <BannerForm
                key={banner?.id ?? 'create'}
                banner={banner}
                promos={promos}
                nextSortOrder={nextSortOrder}
                onClose={onClose}
            />
        </SlideOver>
    );
}
