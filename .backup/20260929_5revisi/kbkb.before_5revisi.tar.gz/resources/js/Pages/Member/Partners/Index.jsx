import { Head, Link, router } from '@inertiajs/react';
import { useState, useCallback } from 'react';
import MemberLayout from '@/Layouts/MemberLayout';
import Pagination from '@/Components/Pagination';
import EmptyState from '@/Components/EmptyState';
import Reveal from '@/Components/Reveal';
import { formatDate, formatRupiah } from '@/Utils/format';
import { rememberBackSource } from '@/Utils/backNav';
import { useTranslation } from '@/i18n';

const TABS = [
    { key: 'promos', labelKey: 'partners.tab.promos' },
    { key: 'partners', labelKey: 'partners.tab.partners' },
];

function PromoCard({ promo }) {
    const { t } = useTranslation();

    return (
        <Link
            href={route('member.promos.show', promo.id)}
            onClick={() => rememberBackSource('promo')}
            className="group flex h-full items-stretch gap-3 overflow-hidden rounded-xl border border-ink/10 bg-white/80 shadow-lift transition-all hover:-translate-y-1 hover:shadow-card"
        >
            <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 bg-ink px-3 py-2 text-paper">
                    <span className="font-display text-base font-bold text-gold-light">
                        {promo.discount_type === 'percent' ? `${promo.discount_value}%` : formatRupiah(promo.discount_value)}
                    </span>
                    <span className="ml-auto truncate rounded-full bg-gold/15 px-2 py-0.5 font-mono text-[9px] uppercase tracking-widest text-gold-light">
                        {promo.partner?.name}
                    </span>
                </div>
                <div className="p-3">
                    <h3 className="line-clamp-2 font-display text-sm font-bold leading-snug text-ink">{promo.title}</h3>
                    {promo.min_purchase > 0 && (
                        <p className="mt-1.5 font-mono text-[10px] text-gold-deep">
                            {t('partners.minSpend', { value: formatRupiah(promo.min_purchase) })}
                        </p>
                    )}
                    <p className="mt-2 font-mono text-[10px] uppercase tracking-wide text-slate-soft">
                        {formatDate(promo.start_date)} — {formatDate(promo.end_date)}
                    </p>
                </div>
            </div>
            {promo.promo_image_url ? (
                <img src={promo.promo_image_url} alt={promo.title} className="my-auto mr-3 h-16 w-16 shrink-0 rounded-lg object-cover" />
            ) : promo.partner?.logo_url ? (
                <img src={promo.partner.logo_url} alt={promo.partner.name} className="my-auto mr-3 h-12 w-12 shrink-0 rounded-lg object-cover" />
            ) : (
                <span className="my-auto mr-3 flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-ink font-display text-lg font-bold text-gold-light">
                    {promo.partner?.name?.charAt(0) || '?'}
                </span>
            )}
        </Link>
    );
}

function PartnerCard({ partner }) {
    const { t } = useTranslation();

    return (
        <Link
            href={route('member.partners.show', partner.id)}
            className="group flex h-full items-start gap-3 rounded-xl border border-ink/10 bg-white/80 p-3 shadow-lift transition-all hover:-translate-y-1 hover:shadow-card"
        >
            <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                    <h3 className="truncate font-display text-sm font-bold leading-snug text-ink">{partner.name}</h3>
                </div>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-gold-deep">{partner.category}</p>
                <p className="mt-1.5 line-clamp-2 text-xs text-slate">{partner.description}</p>
                <div className="mt-2 flex items-center justify-between border-t border-ink/5 pt-2">
                    <span className="text-[11px] text-slate-soft">{t('partners.promosCount', { n: partner.promos_count })}</span>
                    <span className="text-xs font-semibold text-ink transition-transform group-hover:translate-x-1">→</span>
                </div>
            </div>
            {partner.logo_url ? (
                <img src={partner.logo_url} alt={partner.name} className="h-12 w-12 shrink-0 rounded-lg object-cover" />
            ) : (
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-ink font-display text-lg font-bold text-gold-light">
                    {partner.name.charAt(0)}
                </span>
            )}
        </Link>
    );
}

export default function PartnerIndex({ partners, promos, categories, filters }) {
    const { t } = useTranslation();

    const [tab, setTab] = useState(
        () => new URLSearchParams(window.location.search).get('tab') === 'partners' ? 'partners' : 'promos',
    );
    const [search, setSearch] = useState(filters?.search || '');

    const rawCategory = filters?.category || 'all';
    const category = rawCategory === '' ? 'all' : rawCategory;

    const applyFilters = useCallback((overrides = {}) => {
        const params = {
            ...(category !== 'all' ? { category } : {}),
            ...(search ? { search } : {}),
            ...(tab === 'partners' ? { tab } : {}),
            ...overrides,
        };
        // clean undefined
        Object.keys(params).forEach(k => params[k] === undefined && delete params[k]);
        router.get(route('member.partners.index'), params, { preserveState: true, replace: true });
    }, [category, search, tab]);

    const switchTab = (next) => {
        setTab(next);
        applyFilters({ tab: next === 'promos' ? undefined : next });
    };

    const selectCategory = (value) => {
        applyFilters({ category: value === 'all' ? undefined : value });
    };

    const handleSearch = (e) => {
        e.preventDefault();
        applyFilters();
    };

    const categoryList = Array.isArray(categories) ? categories : Object.values(categories || {});
    const promoList = Array.isArray(promos) ? promos : promos?.data ?? [];
    const partnerList = Array.isArray(partners) ? partners : partners?.data ?? [];

    const Chips = (
        <div className="flex flex-wrap gap-2">
            {['all', ...categoryList].map((cat) => (
                <button
                    key={cat}
                    onClick={() => selectCategory(cat)}
                    className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                        category === cat ? 'bg-ink text-paper' : 'border border-ink/15 bg-white/70 text-slate hover:bg-white'
                    }`}
                >
                    {cat === 'all' ? t('partners.filter.all') : cat}
                </button>
            ))}
        </div>
    );

    return (
        <>
            <Head title={t('partners.headTitle')} />

            <div className="flex flex-col gap-8">
                <header className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
                    <h1 className="font-display text-3xl font-bold tracking-tight">{t('partners.headTitle')}</h1>
                    <div className="inline-flex w-fit rounded-full border border-ink/10 bg-white/70 p-1">
                        {TABS.map((item) => (
                            <button
                                key={item.key}
                                onClick={() => switchTab(item.key)}
                                className={`rounded-full px-5 py-2 text-sm font-medium transition-colors ${
                                    tab === item.key ? 'bg-ink text-paper' : 'text-slate hover:text-ink'
                                }`}
                            >
                                {t(item.labelKey)}
                            </button>
                        ))}
                    </div>
                </header>

                <form onSubmit={handleSearch} className="flex gap-2">
                    <input
                        type="text"
                        placeholder={t('partners.searchPlaceholder')}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="input flex-1"
                    />
                    <button type="submit" className="btn-ghost border border-ink/15 bg-white/70 px-4 py-2 text-sm font-medium text-ink hover:bg-white">
                        {t('common.search')}
                    </button>
                </form>

                {tab === 'promos' ? (
                    <>
                        <div className="flex flex-wrap gap-2">{Chips}</div>

                        {promoList.length === 0 ? (
                            <EmptyState
                                title={t('partners.emptyPromos.title')}
                                description={t('partners.emptyPromos.desc')}
                            />
                        ) : (
                            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                                {promoList.map((promo, i) => (
                                    <Reveal key={promo.id} delay={i * 0.05}>
                                        <PromoCard promo={promo} />
                                    </Reveal>
                                ))}
                            </div>
                        )}

                        <Pagination links={promos?.links} />
                    </>
                ) : (
                    <>
                        <div className="flex flex-wrap gap-2">{Chips}</div>

                        {partnerList.length === 0 ? (
                            <EmptyState
                                title={t('partners.emptyPartners.title')}
                                description={t('partners.emptyPartners.desc')}
                            />
                        ) : (
                            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                                {partnerList.map((partner, i) => (
                                    <Reveal key={partner.id} delay={i * 0.05}>
                                        <PartnerCard partner={partner} />
                                    </Reveal>
                                ))}
                            </div>
                        )}

                        <Pagination links={partners?.links} />
                    </>
                )}
            </div>
        </>
    );
}

PartnerIndex.layout = (page) => <MemberLayout>{page}</MemberLayout>;
