<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

#[Fillable(['name', 'nickname', 'email', 'password', 'otp_code', 'otp_expires_at', 'otp_purpose', 'role', 'approval_status', 'must_change_password', 'phone', 'whatsapp', 'company', 'avatar', 'avatar_changes_count', 'member_code', 'card_token', 'notification_settings', 'gender', 'religion', 'birth_date', 'birth_place', 'hobbies', 'marital_status', 'place_of_worship_address', 'city', 'address', 'district', 'business_fields', 'business_address', 'business_district', 'business_city', 'industry', 'businesses', 'is_household'])]
#[Hidden(['password', 'remember_token', 'otp_code'])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    public const ROLE_MEMBER = 'member';

    public const ROLE_ADMIN = 'admin';

    public const ROLE_VENDOR = 'vendor';

    public const ROLES = [self::ROLE_MEMBER, self::ROLE_ADMIN, self::ROLE_VENDOR];

    public const APPROVAL_PENDING = 'pending';

    public const APPROVAL_APPROVED = 'approved';

    public const APPROVAL_REJECTED = 'rejected';

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'otp_expires_at' => 'datetime',
            'notification_settings' => 'array',
            'birth_date' => 'date',
            'must_change_password' => 'boolean',
            'hobbies' => 'array',
            'business_fields' => 'array',
            'businesses' => 'array',
            'is_household' => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::creating(function (User $user) {
            if ($user->role === self::ROLE_MEMBER) {
                $user->card_token ??= (string) Str::uuid();
                $user->member_code ??= DB::transaction(fn () => self::nextMemberCode());
            }
        });
    }

    private static function nextMemberCode(): string
    {
        // ponytail: 3 digit urut per bulan; lewat 999/bulan akan unik-check gagal — naik ke 4 digit jika pernah terjadi.
        $prefix = '7030'.now()->format('ym');

        // Suffix tepat 3 karakter: kode lama (10 char) tidak ikut ter-matching.
        $lastInMonth = DB::table('users')
            ->where('role', self::ROLE_MEMBER)
            ->where('member_code', 'like', $prefix.'___')
            ->orderByDesc('member_code')
            ->value('member_code');

        $next = 1;

        if ($lastInMonth) {
            $next = ((int) substr($lastInMonth, -3)) + 1;
        }

        return $prefix.str_pad((string) $next, 3, '0', STR_PAD_LEFT);
    }

    public function membership(): HasOne
    {
        return $this->hasOne(Membership::class, 'member_id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class, 'member_id');
    }

    public function memberTransactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'member_id');
    }

    public function partner(): HasOne
    {
        return $this->hasOne(Partner::class, 'user_id');
    }

    public function scans(): HasMany
    {
        return $this->hasMany(MemberScan::class, 'member_id');
    }

    public function vendorScans(): HasMany
    {
        return $this->hasMany(MemberScan::class, 'scanned_by_vendor_id');
    }

    public function appNotifications(): HasMany
    {
        return $this->hasMany(AppNotification::class, 'user_id');
    }

    public function communityInfos(): HasMany
    {
        return $this->hasMany(CommunityInfo::class, 'created_by');
    }

    public function isAdmin(): bool
    {
        return $this->role === self::ROLE_ADMIN;
    }

    public function isVendor(): bool
    {
        return $this->role === self::ROLE_VENDOR;
    }

    public function isMember(): bool
    {
        return $this->role === self::ROLE_MEMBER;
    }

    public function isApproved(): bool
    {
        return $this->approval_status === self::APPROVAL_APPROVED;
    }

    public function isPendingApproval(): bool
    {
        return $this->approval_status === self::APPROVAL_PENDING;
    }

    public function needsPasswordChange(): bool
    {
        return (bool) $this->must_change_password;
    }

    public function homeRoute(): string
    {
        return match ($this->role) {
            self::ROLE_ADMIN => 'admin.dashboard',
            self::ROLE_VENDOR => 'vendor.dashboard',
            default => 'member.home',
        };
    }

    public function hasActiveMembership(): bool
    {
        return $this->membership?->isActive() ?? false;
    }

    public function membershipIsActive(): bool
    {
        return $this->hasActiveMembership();
    }

    public function membershipExpiresAt(): ?string
    {
        return $this->membership?->expires_at;
    }

    public function ensureCardToken(): string
    {
        if ($this->card_token) {
            return $this->card_token;
        }

        $token = Str::uuid()->toString();

        $this->forceFill(['card_token' => $token])->save();

        return $token;
    }

    public function ensureMemberCode(): string
    {
        if ($this->member_code) {
            return $this->member_code;
        }

        $code = self::nextMemberCode();

        $this->forceFill(['member_code' => $code])->save();

        return $code;
    }

    public function avatarUrl(): ?string
    {
        if (! $this->avatar) {
            return null;
        }

        return '/storage/'.$this->avatar;
    }
}
