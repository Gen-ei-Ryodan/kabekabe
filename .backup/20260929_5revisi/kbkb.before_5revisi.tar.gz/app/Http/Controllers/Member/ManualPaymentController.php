<?php

namespace App\Http\Controllers\Member;

use App\Http\Controllers\Controller;
use App\Models\MembershipDiscountCode;
use App\Models\MembershipPlan;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ManualPaymentController extends Controller
{
    public function __construct(
        private readonly PaymentService $payments,
    ) {}

    /**
     * Request manual transfer checkout for membership plan.
     */
    public function checkout(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'plan_id' => ['required', 'integer', 'exists:membership_plans,id'],
            'promo_code' => ['nullable', 'string', 'max:50'],
        ]);

        $member = $request->user();
        $plan = MembershipPlan::where('is_active', true)->findOrFail($validated['plan_id']);

        $planPrice = (int) $plan->price;
        $discountAmount = 0;
        $discountCode = null;

        if (! empty($validated['promo_code'])) {
            $discountCode = MembershipDiscountCode::where('code', strtoupper(trim($validated['promo_code'])))->first();
            if ($discountCode && $discountCode->isValid()) {
                $discountAmount = $discountCode->calculateDiscount($planPrice);
            }
        }

        $finalPrice = max(0, $planPrice - $discountAmount);

        // Jika 100% Free: langsung aktivasi membership tanpa transfer
        if ($finalPrice === 0 && $discountAmount > 0) {
            $payment = $this->payments->createPending($member, $plan);
            $payment->forceFill([
                'amount' => 0,
                'paid_at' => now(),
                'notes' => "Aktivasi Promo 100% Bebas Biaya ({$discountCode->code})",
            ])->save();

            $this->payments->approve($payment, null, "Aktivasi Membership via Voucher {$discountCode->code}");
            $discountCode->increment('used_count');

            return response()->json([
                'success' => true,
                'is_free' => true,
                'payment_id' => $payment->id,
                'invoice_number' => $payment->invoice_number,
                'amount' => 0,
                'message' => 'Selamat! Keanggotaan Anda telah aktif gratis via voucher diskon.',
            ]);
        }

        // Cek order pending sebelumnya agar order tetap 1 dalam 24 jam
        $existing = Payment::where('member_id', $member->id)
            ->where('status', Payment::STATUS_PENDING)
            ->whereNull('proof_path')
            ->where('created_at', '>=', now()->subHours(24))
            ->latest()
            ->first();

        if ($existing) {
            if ($existing->plan_id === $plan->id && (int) $existing->amount === (int) $finalPrice) {
                $expiresAt = $existing->created_at->addHours(24);
                return response()->json([
                    'success' => true,
                    'is_free' => false,
                    'payment_id' => $existing->id,
                    'invoice_number' => $existing->invoice_number,
                    'amount' => (int) $existing->amount,
                    'plan_id' => $existing->plan_id,
                    'plan_name' => $plan->name,
                    'duration_months' => $plan->duration_months,
                    'stage' => 'unpaid',
                    'stage_label' => 'Belum Dibayar',
                    'created_at' => $existing->created_at->translatedFormat('d M Y H:i'),
                    'expires_at_timestamp' => $expiresAt->timestamp,
                    'remaining_seconds' => max(0, now()->diffInSeconds($expiresAt, false)),
                ]);
            }

            // Jika member memilih paket berbeda, expire order lama agar order tetap 1
            $existing->update([
                'status' => Payment::STATUS_EXPIRED,
                'notes' => ($existing->notes ? $existing->notes . ' | ' : '') . 'Diganti dengan order baru oleh member.',
            ]);
        }

        // Buat record pembayaran pending untuk verifikasi manual
        $payment = $this->payments->createPending($member, $plan);
        $notes = "Manual Transfer Payment | Paket: {$plan->name}";
        if ($discountAmount > 0) {
            $notes .= " | Voucher ({$discountCode->code}): -Rp" . number_format($discountAmount, 0, ',', '.');
        }

        $payment->forceFill([
            'amount' => $finalPrice,
            'paid_at' => null,
            'notes' => $notes,
        ])->save();

        if ($discountCode) {
            $discountCode->increment('used_count');
        }

        $expiresAt = $payment->created_at->addHours(24);

        return response()->json([
            'success' => true,
            'is_free' => false,
            'payment_id' => $payment->id,
            'invoice_number' => $payment->invoice_number,
            'amount' => (int) $payment->amount,
            'plan_id' => $payment->plan_id,
            'plan_name' => $plan->name,
            'duration_months' => $plan->duration_months,
            'stage' => 'unpaid',
            'stage_label' => 'Belum Dibayar',
            'created_at' => $payment->created_at->translatedFormat('d M Y H:i'),
            'expires_at_timestamp' => $expiresAt->timestamp,
            'remaining_seconds' => max(0, now()->diffInSeconds($expiresAt, false)),
        ]);
    }

    /**
     * Upload payment proof for manual transfer payment.
     */
    public function uploadProof(Request $request, Payment $payment): JsonResponse
    {
        $user = $request->user();
        if ($payment->member_id !== $user->id) {
            return response()->json([
                'success' => false,
                'message' => 'Akses ditolak.',
            ], 403);
        }

        if ($payment->status !== Payment::STATUS_PENDING) {
            return response()->json([
                'success' => false,
                'message' => 'Status invoice ini tidak dapat diunggah bukti lagi (' . $payment->status . ').',
            ], 422);
        }

        $request->validate([
            'proof' => ['required', 'file', 'image', 'max:5120'], // max 5MB
        ]);

        $file = $request->file('proof');
        $path = $file->store('proofs', 'public');

        $payment->forceFill([
            'proof_path' => $path,
            'paid_at' => now(),
            'notes' => trim(($payment->notes ? $payment->notes . ' | ' : '') . 'Bukti transfer diunggah member pada ' . now()->translatedFormat('d M Y H:i:s')),
        ])->save();

        return response()->json([
            'success' => true,
            'message' => 'Bukti pembayaran berhasil diunggah! Pembayaran Anda akan segera diverifikasi oleh tim admin KBKB.',
            'proof_url' => $payment->proofUrl(),
            'payment' => [
                'id' => $payment->id,
                'invoice_number' => $payment->invoice_number,
                'amount' => $payment->amount,
                'paid_at' => $payment->paid_at?->translatedFormat('d M Y H:i'),
                'payment_proof_url' => $payment->proofUrl(),
                'stage' => 'paid',
                'stage_label' => 'Sudah Dibayar (Menunggu Verifikasi Admin)',
            ],
        ]);
    }

    /**
     * Cancel an uncompleted pending payment.
     */
    public function cancel(Request $request, Payment $payment): JsonResponse
    {
        $user = $request->user();
        if ($payment->member_id !== $user->id) {
            return response()->json(['success' => false, 'message' => 'Akses ditolak.'], 403);
        }

        if ($payment->status === Payment::STATUS_PENDING && ! $payment->proof_path) {
            $payment->update([
                'status' => Payment::STATUS_EXPIRED,
                'notes' => ($payment->notes ? $payment->notes . ' | ' : '') . 'Dibatalkan oleh member.',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Pesanan pembayaran berhasil dibatalkan.',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Transaksi tidak dapat dibatalkan.',
        ], 422);
    }
}
