<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\RejectPromoRequest;
use App\Http\Requests\UpdatePromoRequest;
use App\Models\Promo;
use App\Services\PromoService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class PromoController extends Controller
{
    public function __construct(
        private readonly PromoService $promos,
    ) {}

    public function index(Request $request): Response
    {
        $this->promos->deactivateExpired();

        $query = Promo::query()->with('partner:id,name,category,logo');

        $status = $request->string('status')->toString();
        $search = $request->string('search')->toString();

        if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
            $query->where('status', $status);
        }

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                    ->orWhereHas('partner', fn ($p) => $p->where('name', 'like', "%{$search}%"));
            });
        }

        $promos = $query->orderByRaw("CASE status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 WHEN 'rejected' THEN 2 ELSE 3 END")
            ->orderByRaw('COALESCE(sort_number, 999999) ASC')
            ->orderByDesc('created_at')
            ->paginate(12)
            ->withQueryString();

        $drawer = $this->drawerPayload($request);

        if ($drawer !== null) {
            $promos->appends($request->except(['drawer', 'id']));
        }

        return Inertia::render('Admin/Promos/Index', [
            'promos' => $promos,
            'filters' => ['status' => $status, 'search' => $search],
            'drawer' => $drawer,
        ]);
    }

    private function drawerPayload(Request $request): ?array
    {
        $mode = $request->string('drawer')->toString();

        if ($mode !== 'edit') {
            return null;
        }

        $promo = Promo::query()->with('partner:id,name,category')->find($request->integer('id'));

        if (! $promo) {
            return null;
        }

        return [
            'mode' => 'edit',
            'promo' => $promo,
        ];
    }

    public function edit(Promo $promo): Response
    {
        return Inertia::render('Admin/Promos/Edit', [
            'promo' => $promo->load('partner:id,name,category'),
        ]);
    }

    public function update(UpdatePromoRequest $request, Promo $promo): RedirectResponse
    {
        $promo->update($request->validated());

        return redirect()
            ->route('admin.promos.index')
            ->with('success', 'Promo updated successfully.');
    }

    public function reorder(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'items' => ['required', 'array'],
            'items.*.id' => ['required', 'integer', 'exists:promos,id'],
            'items.*.sort_number' => ['required', 'integer', 'min:1'],
        ]);

        \Illuminate\Support\Facades\DB::transaction(function () use ($validated) {
            foreach ($validated['items'] as $item) {
                Promo::where('id', $item['id'])->update(['sort_number' => $item['sort_number']]);
            }
        });

        return back()->with('success', 'Urutan promo berhasil diperbarui.');
    }

    public function updateSort(Request $request, Promo $promo): RedirectResponse
    {
        $validated = $request->validate([
            'sort_number' => ['nullable', 'integer', 'min:1'],
        ]);

        $promo->update([
            'sort_number' => $validated['sort_number'] ?? null,
        ]);

        return back()->with('success', 'Nomor urut promo berhasil diperbarui.');
    }

    public function approve(Request $request, Promo $promo): RedirectResponse
    {
        $this->promos->approve($promo, $request->user());

        return back()->with('success', 'Promo approved and now visible to members.');
    }

    public function reject(RejectPromoRequest $request, Promo $promo): RedirectResponse
    {
        $this->promos->reject($promo, $request->user(), $request->input('reason'));

        return back()->with('success', 'Promo rejected.');
    }

    public function toggle(Request $request, Promo $promo): RedirectResponse
    {
        abort_unless($promo->status === Promo::STATUS_APPROVED, 422);

        $promo->update(['is_active' => $request->boolean('is_active')]);

        return back()->with('success', $promo->is_active ? 'Promo activated.' : 'Promo deactivated.');
    }
}