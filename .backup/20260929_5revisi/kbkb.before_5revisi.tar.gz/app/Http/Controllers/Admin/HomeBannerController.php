<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HomeBanner;
use App\Models\HomePopup;
use App\Models\PartnerAd;
use App\Models\Promo;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class HomeBannerController extends Controller
{
    public function index(Request $request): Response
    {
        $query = HomeBanner::query()->where('type', HomeBanner::TYPE_PROMO)->with('promo.partner:id,name');

        $status = $request->string('status')->toString();

        if ($status === 'active') {
            $query->where('is_active', true);
        } elseif ($status === 'inactive') {
            $query->where('is_active', false);
        }

        $banners = $query->orderBy('sort_order')
            ->get()
            ->map(fn (HomeBanner $banner) => [
                'id' => $banner->id,
                'image_url' => $banner->imageUrl(),
                'target_title' => $banner->promo_title ?: $banner->promo?->title,
                'promo_title' => $banner->promo_title,
                'promo_id' => $banner->promo_id,
                'sort_order' => $banner->sort_order,
                'is_active' => $banner->is_active,
                'promo' => $banner->promo
                    ? ['id' => $banner->promo->id, 'title' => $banner->promo->title, 'partner' => ['name' => $banner->promo->partner?->name]]
                    : null,
            ])
            ->all();

        $partnerAds = PartnerAd::query()
            ->with(['partner:id,name', 'promo:id,title'])
            ->latest('created_at')
            ->get()
            ->map(fn (PartnerAd $ad) => [
                'id' => $ad->id,
                'partner_name' => $ad->partner?->name,
                'type' => $ad->type,
                'type_label' => $ad->type === PartnerAd::TYPE_POPUP ? 'Pop-up Pembuka (3 Hari)' : 'Banner Beranda (5 Hari)',
                'promo_title' => $ad->promo_title ?: $ad->promo?->title,
                'image_url' => $ad->imageUrl(),
                'start_date' => $ad->start_date?->format('d M Y'),
                'end_date' => $ad->end_date?->format('d M Y'),
                'status' => $ad->status,
                'notes' => $ad->notes,
                'admin_feedback' => $ad->admin_feedback,
                'created_at' => $ad->created_at?->format('d M Y H:i'),
                'paid_at' => $ad->paid_at?->format('d M Y H:i'),
            ]);

        $drawer = $this->drawerPayload($request);
        $paidAdsCount = PartnerAd::query()->where('status', 'paid')->count();

        return Inertia::render('Admin/Banners/Index', [
            'banners' => $banners,
            'partner_ads' => $partnerAds,
            'paid_ads_count' => $paidAdsCount,
            'initial_tab' => $request->string('tab')->toString() ?: 'banners',
            'filters' => ['status' => $status],
            'promos' => $this->promoSelect(),
            'drawer' => $drawer,
            'popup' => $this->popupPayload(),
            'popup_promos' => $this->promoSelect(),
        ]);
    }

    private function drawerPayload(Request $request): ?array
    {
        $mode = $request->string('drawer')->toString();

        if (! in_array($mode, ['create', 'edit'], true)) {
            return null;
        }

        $drawer = ['mode' => $mode];

        if ($mode === 'edit') {
            $banner = HomeBanner::query()
                ->with('promo:id,title,partner_id')
                ->find($request->integer('id'));

            if ($banner) {
                $drawer['banner'] = $banner;
            }
        }

        return $drawer;
    }

    public function create(): Response
    {
        return Inertia::render('Admin/Banners/Index', [
            'drawer' => ['mode' => 'create'],
            'promos' => $this->promoSelect(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateBanner($request);

        HomeBanner::create($validated);

        return redirect()
            ->route('admin.banners.index')
            ->with('success', 'Home banner created successfully.');
    }

    public function edit(HomeBanner $banner): Response
    {
        return Inertia::render('Admin/Banners/Index', [
            'drawer' => [
                'mode' => 'edit',
                'banner' => $banner->load('promo:id,title,partner_id'),
            ],
            'promos' => $this->promoSelect(),
        ]);
    }

    public function update(Request $request, HomeBanner $banner): RedirectResponse
    {
        $validated = $this->validateBanner($request, $banner);

        $banner->update($validated);

        return redirect()
            ->route('admin.banners.index')
            ->with('success', 'Home banner updated successfully.');
    }

    public function toggle(Request $request, HomeBanner $banner): RedirectResponse
    {
        $activate = $request->boolean('is_active');

        if ($activate && ! $banner->is_active) {
            $active = HomeBanner::query()
                ->where('type', HomeBanner::TYPE_PROMO)
                ->where('is_active', true)
                ->where('id', '!=', $banner->id)
                ->count();

            if ($active >= 4) {
                throw ValidationException::withMessages([
                    'is_active' => 'Maksimal 4 banner aktif dikelola admin (Slot 1 otomatis dari Pop-up Pembuka).',
                ]);
            }
        }

        $banner->update(['is_active' => $activate]);

        return back()->with('success', $activate ? 'Home banner activated.' : 'Home banner deactivated.');
    }

    public function destroy(HomeBanner $banner): RedirectResponse
    {
        $banner->delete();

        return redirect()
            ->route('admin.banners.index')
            ->with('success', 'Home banner deleted.');
    }

    public function updatePopup(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'promo_id' => ['required', 'integer', Rule::exists('promos', 'id')],
            'promo_title' => ['nullable', 'string', 'max:255'],
            'is_active' => ['required', 'boolean'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048', 'dimensions:max_width=2000,max_height=2000'],
            'remove_image' => ['nullable', 'boolean'],
        ]);

        $popup = HomePopup::query()->first();
        $data = [
            'promo_id' => $validated['promo_id'],
            'promo_title' => $validated['promo_title'] ?? null,
            'is_active' => $validated['is_active'],
        ];

        if ($request->hasFile('image')) {
            if ($popup?->image_path) {
                \Illuminate\Support\Facades\Storage::disk('public')->delete($popup->image_path);
            }
            $data['image_path'] = $request->file('image')->store('home-popups', 'public');
        } elseif ($request->boolean('remove_image') && $popup?->image_path) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($popup->image_path);
            $data['image_path'] = null;
        }

        $popup ??= new HomePopup();
        $popup->fill($data);
        $popup->save();

        return redirect()->route('admin.banners.index')->with('success', 'Opening popup settings saved.');
    }

    private function popupPayload(): ?array
    {
        $popup = HomePopup::query()->with('promo.partner')->first();

        return $popup ? [
            'id' => $popup->id,
            'promo_id' => $popup->promo_id,
            'promo_title' => $popup->promo_title,
            'image_path' => $popup->image_path,
            'image_url' => $popup->imageUrl(),
            'is_active' => $popup->is_active,
            'promo' => $popup->promo ? [
                'title' => $popup->promo->title,
                'partner' => ['name' => $popup->promo->partner?->name],
            ] : null,
        ] : null;
    }

    private function validateBanner(Request $request, ?HomeBanner $banner = null): array
    {
        $validated = $request->validate([
            'promo_id' => ['required', 'integer', Rule::exists('promos', 'id')],
            'promo_title' => ['nullable', 'string', 'max:255'],
            'sort_order' => ['required', 'integer', 'min:1'],
            'is_active' => ['required', 'boolean'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'remove_image' => ['nullable', 'boolean'],
        ]);

        $validated['type'] = HomeBanner::TYPE_PROMO;
        $validated['agenda_id'] = null;

        unset($validated['image'], $validated['remove_image']);

        if ($request->hasFile('image')) {
            if ($banner?->image_path) {
                \Illuminate\Support\Facades\Storage::disk('public')->delete($banner->image_path);
            }

            $validated['image_path'] = $request->file('image')->store('banners', 'public');
        } elseif ($request->boolean('remove_image') && $banner?->image_path) {
            \Illuminate\Support\Facades\Storage::disk('public')->delete($banner->image_path);
            $validated['image_path'] = null;
        }

        if ($request->boolean('is_active')) {
            $active = HomeBanner::query()
                ->where('type', HomeBanner::TYPE_PROMO)
                ->where('is_active', true);

            if ($banner !== null) {
                $active->where('id', '!=', $banner->id);
            }

            if ($active->count() >= 4) {
                throw ValidationException::withMessages([
                    'is_active' => 'Maksimal 4 banner aktif dikelola admin (Slot 1 otomatis dari Pop-up Pembuka).',
                ]);
            }
        }

        return $validated;
    }

    public function approveAd(PartnerAd $ad): RedirectResponse
    {
        $ad->update([
            'status' => PartnerAd::STATUS_APPROVED,
            'approved_at' => now(),
        ]);

        return back()->with('success', 'Pengajuan iklan partner disetujui.');
    }

    public function rejectAd(Request $request, PartnerAd $ad): RedirectResponse
    {
        $ad->update([
            'status' => PartnerAd::STATUS_REJECTED,
            'admin_feedback' => $request->input('reason'),
        ]);

        return back()->with('success', 'Pengajuan iklan partner ditolak.');
    }

    public function markPaidAd(PartnerAd $ad): RedirectResponse
    {
        $ad->update([
            'status' => PartnerAd::STATUS_PAID,
            'paid_at' => now(),
        ]);

        return back()->with('success', 'Status iklan diperbarui menjadi Sudah Dibayar.');
    }

    public function publishAd(PartnerAd $ad): RedirectResponse
    {
        if ($ad->type === PartnerAd::TYPE_POPUP) {
            $popup = HomePopup::first() ?? new HomePopup();
            $popup->fill([
                'promo_id' => $ad->promo_id,
                'promo_title' => $ad->promo_title,
                'image_path' => $ad->image_path,
                'is_active' => true,
            ]);
            $popup->save();

            $ad->update(['status' => 'active']);

            return back()->with('success', 'Iklan partner berhasil ditayangkan sebagai Popup Pembuka Beranda!');
        }

        $maxOrder = HomeBanner::query()->max('sort_order') ?? 0;
        HomeBanner::create([
            'promo_id' => $ad->promo_id,
            'agenda_id' => null,
            'type' => HomeBanner::TYPE_PROMO,
            'promo_title' => $ad->promo_title,
            'image_path' => $ad->image_path,
            'sort_order' => $maxOrder + 1,
            'is_active' => true,
        ]);

        $ad->update(['status' => 'active']);

        return back()->with('success', 'Iklan partner berhasil ditayangkan sebagai Banner Beranda!');
    }

    private function promoSelect(): array
    {
        return Promo::query()
            ->visibleToMembers()
            ->get(['id', 'title', 'partner_id'])
            ->map(fn (Promo $promo) => [
                'id' => $promo->id,
                'title' => $promo->title,
                'partner' => $promo->partner?->name,
            ])
            ->all();
    }

}
