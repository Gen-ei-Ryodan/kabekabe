<?php

namespace App\Services;

use App\Mail\PromoApprovedMail;
use App\Models\Promo;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Throwable;

class PromoService
{
    public function __construct(
        private readonly NotificationService $notifications,
    ) {}

    public function deactivateExpired(): int
    {
        return Promo::query()
            ->where('is_active', true)
            ->whereNotNull('end_date')
            ->whereDate('end_date', '<', now()->toDateString())
            ->update(['is_active' => false]);
    }

    public function submit(Promo $promo, User $vendor): Promo
    {
        $promo->forceFill([
            'status' => Promo::STATUS_PENDING,
            'submitted_at' => now(),
            'reviewed_at' => null,
            'reviewed_by' => null,
            'rejection_reason' => null,
        ])->save();

        $this->notifications->send(
            User::query()->where('role', User::ROLE_ADMIN)->first()?->id
                ?? throw new \RuntimeException('Admin not found.'),
            'New Promo Pending Review',
            "Promo \"{$promo->title}\" from {$promo->partner->name} is awaiting approval.",
            'promo',
            '/admin/promos?status=pending',
        );

        return $promo->fresh();
    }

    public function approve(Promo $promo, User $admin): Promo
    {
        $promo->forceFill([
            'status' => Promo::STATUS_APPROVED,
            'reviewed_by' => $admin->id,
            'reviewed_at' => now(),
            'rejection_reason' => null,
        ])->save();

        $this->notifications->broadcastToMembers(
            'New Promo Available',
            "Promo \"{$promo->title}\" from {$promo->partner->name} is now available to active members.",
            'promo',
            "/member/promos/{$promo->id}",
        );

        $this->emailMembers($promo);

        return $promo->fresh();
    }

    /**
     * Kirim email broadcast promo baru ke seluruh member.
     * Kegagalan per penerima tidak menggagalkan persetujuan promo.
     */
    private function emailMembers(Promo $promo): int
    {
        $members = User::query()
            ->where('role', User::ROLE_MEMBER)
            ->whereNotNull('email')
            ->get();

        $sent = 0;

        foreach ($members as $member) {
            try {
                Mail::to($member->email)->send(new PromoApprovedMail($member, $promo));
                $sent++;
            } catch (Throwable $e) {
                report($e);
            }
        }

        return $sent;
    }

    public function reject(Promo $promo, User $admin, string $reason): Promo
    {
        $promo->forceFill([
            'status' => Promo::STATUS_REJECTED,
            'reviewed_by' => $admin->id,
            'reviewed_at' => now(),
            'rejection_reason' => $reason,
        ])->save();

        $this->notifications->send(
            $promo->partner->user,
            'Promo Rejected',
            "Promo \"{$promo->title}\" was rejected. Reason: {$reason}",
            'promo',
            "/vendor/promos/{$promo->id}/edit",
        );

        return $promo->fresh();
    }
}
